import React from 'react'
import AddProduct from './AddProduct';
import ProductsList from './ProductsList';
import { useState } from "react";


export default function Admin() {

    const [productId, setProductId] = useState("");

    const getProductIdHandler = (id) => {
        console.log("The ID of document to be edited: ", id);
        setProductId(id);
    };
    return (
        <div style={{ width: "400px" }}>
                <AddProduct id={productId} setBookId={setProductId} />
                <ProductsList getProductId={getProductIdHandler} />
        </div>
    )
}
